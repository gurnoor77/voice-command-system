using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Speech.Recognition;
using System.Windows.Forms;
using System.Configuration;

namespace VoiceCommandApp
{
    public partial class Form1 : Form
    {
        private SpeechRecognitionEngine recognizer;
        private string connectionString;
        private Label footer;
        private bool isListening = false;

        public Form1()
        {
            InitializeComponent();
            InitializeDashboard();
        }

        private void InitializeDashboard()
        {
            // Footer
            footer = new Label
            {
                Text = "� 2025 Gurnoor Singh | Speech Recognition System",
                Font = new Font("Segoe UI", 9F, FontStyle.Italic),
                ForeColor = Color.Gray,
                AutoSize = true,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left
            };
            this.Controls.Add(footer);
            footer.Location = new Point(30, this.ClientSize.Height - 20);

            // DataGridView Styling
            dataGridView1.ColumnHeadersVisible = true;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.DodgerBlue;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dataGridView1.DefaultCellStyle.Font = new Font("Segoe UI", 11F);
            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.DefaultCellStyle.Padding = new Padding(6);
            dataGridView1.DefaultCellStyle.BackColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke;
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.LightSkyBlue;
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black;

            dataGridView1.RowTemplate.Height = 35;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Hover Effects
            btnStartListening.MouseEnter += (s, e) =>
            {
                if (!isListening)
                    btnStartListening.BackColor = Color.DeepSkyBlue;
            };
            btnStartListening.MouseLeave += (s, e) =>
            {
                if (!isListening)
                    btnStartListening.BackColor = Color.DodgerBlue;
            };

            btnViewHistory.MouseEnter += (s, e) => btnViewHistory.BackColor = Color.DimGray;
            btnViewHistory.MouseLeave += (s, e) => btnViewHistory.BackColor = Color.Gray;

            // Connection String
            connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnStartListening_Click(object sender, EventArgs e)
        {
            if (!isListening)
            {
                try
                {
                    recognizer = new SpeechRecognitionEngine(new System.Globalization.CultureInfo("en-US"));
                    recognizer.SetInputToDefaultAudioDevice();
                    recognizer.UpdateRecognizerSetting("CFGConfidenceRejectionThreshold", 50);

                    Choices commands = new Choices();
                    commands.Add(new string[] {"hello", "exit", "clear","open notepad", "open chrome", "open calculator","open paint", "show date", "show time","lock screen", "minimize window", "maximize window"});

                    Grammar grammar = new Grammar(new GrammarBuilder(commands));
                    recognizer.LoadGrammar(grammar);

                    recognizer.SpeechRecognized += Recognizer_SpeechRecognized;
                    recognizer.RecognizeAsync(RecognizeMode.Multiple);

                    lblStatus.Text = "Listening...";
                    btnStartListening.Text = "Stop Listening";
                    btnStartListening.BackColor = Color.Red;
                    isListening = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error initializing recognizer: " + ex.Message);
                }
            }
            else
            {
                recognizer.RecognizeAsyncStop();
                recognizer.Dispose();
                recognizer = null;

                lblStatus.Text = "Stopped listening.";
                btnStartListening.Text = "Start Listening";
                btnStartListening.BackColor = Color.DodgerBlue;
                isListening = false;
            }
        }

        private void Recognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            float confidence = e.Result.Confidence;
            string cmd = e.Result.Text.ToLower();

            if (confidence >= 0.6)
            {
                txtRecognized.Text = $"Recognized: {cmd}";
                lblStatus.Text = "Command recognized.";
                SaveCommand(cmd);

                switch (cmd)
                {
                    case "hello":
                        MessageBox.Show("Hello! How can I help you?");
                        break;

                    case "exit":
                        Application.Exit();
                        break;

                    case "clear":
                        txtRecognized.Clear();
                        break;

                    case "open notepad":
                        if (Confirm("Open Notepad?"))
                            System.Diagnostics.Process.Start("notepad.exe");
                        break;

                    case "open chrome":
                        if (Confirm("Open Google Chrome?"))
                            System.Diagnostics.Process.Start("chrome.exe");
                        break;

                    case "open calculator":
                        if (Confirm("Open Calculator?"))
                            System.Diagnostics.Process.Start("calc.exe");
                        break;

                    case "show date":
                        MessageBox.Show("Today's date is: " + DateTime.Now.ToShortDateString());
                        break;

                    case "show time":
                        MessageBox.Show("Current time: " + DateTime.Now.ToShortTimeString());
                        break;

                    case "lock screen":
                        if (Confirm("Lock the screen?"))
                            System.Diagnostics.Process.Start("rundll32.exe", "user32.dll,LockWorkStation");
                        break;

                    case "open paint":
                        if (Confirm("Open Paint?"))
                            System.Diagnostics.Process.Start("mspaint.exe");
                        break;

                    case "minimize window":
                        this.WindowState = FormWindowState.Minimized;
                        break;

                    case "maximize window":
                        this.WindowState = FormWindowState.Maximized;
                        break;
                }
            }
            else
            {
                lblStatus.Text = "Voice not recognized - try again.";
            }
        }


        private void btnViewHistory_Click(object sender, EventArgs e)
        {
            if (!dataGridView1.Visible)
            {
                LoadHistory();
                dataGridView1.Visible = true;
                btnViewHistory.Text = "Hide History";
            }
            else
            {
                dataGridView1.Visible = false;
                btnViewHistory.Text = "View History";
            }
        }

        private void LoadHistory()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Commands ORDER BY RecognizedAt DESC", con))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;

                        if (dataGridView1.Columns.Count == 3)
                        {
                            dataGridView1.Columns[0].HeaderText = "Command ID";
                            dataGridView1.Columns[1].HeaderText = "Voice Input";
                            dataGridView1.Columns[2].HeaderText = "Timestamp";

                            // Manually set equal width ratio
                            foreach (DataGridViewColumn col in dataGridView1.Columns)
                            {
                                col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                                col.FillWeight = 33.33f;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
        }

        private void SaveCommand(string command)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Commands (CommandText) VALUES (@cmd)", con))
                    {
                        cmd.Parameters.AddWithValue("@cmd", command);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
        }

        private bool Confirm(string msg)
        {
            return MessageBox.Show(msg, "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}






